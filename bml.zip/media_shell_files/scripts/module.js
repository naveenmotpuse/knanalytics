jQuery.fn.extend({
    k_enable: function() {
        return this.removeClass('disabled').attr("aria-disabled","false").removeAttr("disabled");
    },
    k_disable: function() {
        return this.addClass('disabled').attr("aria-disabled","true").attr("disabled", "disabled");
    },
    k_IsDisabled: function(){
       if( this.hasClass('disabled')){return true;}else{return false;}
    }
  });

 function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}


$(document).ready(function () {
var recordId = Number($.url('?id'))
debugger;
    $.ajax({
       type: "POST",
       url: "/media_library/getRequestedMediaJson",
       data: {'csrfmiddlewaretoken':$("input[name='csrfmiddlewaretoken']").val(), 'record_Id': recordId },
       success: function callback(data){
       debugger;
            gRecordData = JSON.parse(data)
			startRecordPlayer();
			_Navigator.Get().l1p1.dataurl = 'landing.htm'
			setTimeout('_Navigator.Start()',500);
			$("h1:first").focus();
        },
        error: function (xhr, data, message) {
        debugger;
            console.log("Error while pulling data for record id " + $.url('?id'))
        }
    });

    if(_Settings.enableCache)
    {
        _Caching.InitAssetsCaching();
        _Caching.InitPageCaching();
    }
});
