//This api will contain navigation logic and page load.
//It will also handle the question navigation if the page is having multiple questions.
var _Navigator = (function () {
    var _currentPageId = "";
    var _currentPageObject = {};
    var progressLevels = [1];
    var _NData = {
        "l1p1": {
            pageId: "l1p1",
            prevPageId: "",
            nextPageId: "l1p2",
            dataurl: "l1p1.htm",
            datalevel: 0,
            questions: [],
            isStartPage: true,
        },
        "l1p2": {
            pageId: "l1p2",
            prevPageId: "l1p1",
            nextPageId: "",
            dataurl: "QuestionPlayer.htm",
            datalevel: 1,
            questions: [],
        }

    }
    var _StateData = {}

    function OnPageLoad() {
       // _TopSlider.OnLoad();
       // _CustomPage.OnPageLoad();
      // _Navigator.LoadDefaultQuestion();
      if(_currentPageObject.nextPageId == ""){
		$("#linknext").k_disable();
	  }
      if(_currentPageObject.prevPageId == ""){
 		$("#linkprevious").k_disable();
		introHTML = $("<span>" + $(".intro-p").html() + "</span>")
		introHTML.find(".InstructionToRemove").remove()
		introHTML = introHTML.html()
		removeCSS("skeleton.css")
	  }
		if(currentQuestionIndex == 0){
			$("#linkprevious").k_disable();
		}
    }
    return {
        Get: function () {
            return _NData;
        },
        Start: function () {

                this.LoadPage("l1p1");
                setTimeout('$(".main-content").fadeIn(500)',500)

        },
        LoadPage: function (pageId, jsonObj) {
            if (jsonObj == undefined) {
                jsonObj = {};
            }
            _currentPageId = pageId;
            this.UpdateProgressBar();
            _currentPageObject = _NData[_currentPageId]
            if (_currentPageObject.isStartPage != undefined && _currentPageObject.isStartPage) {
                $("#header-title").css("border-bottom", "0px");
                $("#linkprevious").k_disable();
                $("#linknext").k_enable();
            }
            else
            {
				//changeCSS("styles/questionplayer.css",5);
				$("#header-title").css("border-bottom", "1px solid #CCCCCC");
			}
            if(_currentPageObject.hasActivity !=undefined && _currentPageObject.hasActivity){
                $("#linknext").k_disable();
            }
            if (_currentPageObject.isLastPage != undefined && _currentPageObject.isLastPage) {
                $("#linknext").k_disable();
            }

            _currentPageObject.isVisited = true;

            var pageUrl = _Settings.dataRoot + _currentPageObject.dataurl + _Caching.GetUrlExtension();;
            if (_currentPageObject.isStartPage) {
				$("#footer-navigation").hide()
				$('#header-progress').hide();
				$('.infoIcon').hide();
				$('#header-title').find('h1').hide();

                $(".main-content").load(pageUrl, function () {
                    OnPageLoad();
                    setReader("LandingMainHeading")
                });
            } else {
                    $(".main-content").load(pageUrl, function () {
                         OnPageLoad();
                        $("h1").focus();
					});
				/*
                $(".main-content").fadeTo(250, 0.25, function () {
                    $(".main-content").load(pageUrl, function () {
                        $(this).fadeTo(600, 1)
                        OnPageLoad();
                        $("h2.pageheading").focus();
                    });
                })
                */
            }
        },
        LoadDefaultQuestion: function () {
            if (_currentPageObject.questions.length > 0) {
                _questionId = 0;
                _currentPageObject.questions[0].isQuestionVisit = true;
                for (var i = 0; i < _currentPageObject.questions.length; i++) {
                    if (_currentPageObject.questions[i].isCurrent) {
                        _questionId = i;
                    }
                }
                //second parameter is to disable question effect.
                _Question.Load(_currentPageObject.questions[_questionId], {
                    disableEffect: true
                });
            }
        },
        Prev: function () {
            if ( _currentPageObject.pageId == "l1p2" && typeof(currentQuestionIndex) !='undefined'  &&  currentQuestionIndex > 0   ) {
				$("#ReviewIns").hide();
				$(".intro-content-question").show()
				currentQuestionIndex  = currentQuestionIndex - 1
				showQuestion()
				if(currentQuestionIndex == 0){
					$("#linkprevious").k_disable();
				}
            }
            else {
                this.LoadPage(_currentPageObject.prevPageId);
            }
        },
        Next: function () {
			$("#linkprevious").k_enable();
            if(_currentPageObject.customNext!=undefined && !_currentPageObject.customNext.isComplete){
                var custFunction = new Function(_currentPageObject.customNext.jsFunction);
                custFunction();
            }
            else if ( _currentPageObject.pageId == "l1p2" && typeof(currentQuestionIndex) !='undefined' && typeof(gRecordData.Questions) !='undefined'  && (currentQuestionIndex +1) < gRecordData.Questions.length ) {
				currentQuestionIndex  = currentQuestionIndex + 1
				showQuestion()
				this.UpdateProgressBar();

            }
            else if ( _currentPageObject.pageId == "l1p2" && typeof(currentQuestionIndex) !='undefined' && typeof(gRecordData.Questions) !='undefined'  && (currentQuestionIndex +1) == gRecordData.Questions.length ) {
				this.UpdateProgressBar();
				// Show review instruction
				currentQuestionIndex  = currentQuestionIndex + 1
				$(".intro-content-question").hide();
				$("#ReviewIns").show();
			}
            else if ( _currentPageObject.pageId == "l1p2" && typeof(currentQuestionIndex) !='undefined' && typeof(gRecordData.Questions) !='undefined'  && currentQuestionIndex == gRecordData.Questions.length ) {

				// Show summary
				$("#ReviewIns").hide();
				$("#Summary").show();
				$("#Summary").load("pagedata/Summary.htm")
				$("#climate-deal").css("margin-left","23%");
				$("#linknext").k_disable();
			}
            else {
                if (_currentPageObject.IsComplete == undefined || !_currentPageObject.IsComplete) {
                    this.CompletePage()
                }
                this.LoadPage(_currentPageObject.nextPageId);

            }
        },
        GetProgressData: function () {
			var visitpage = 0;
			var correctQs = 0;
            for (var p = 0; p < progressLevels.length; p++) {

                for (var i in _NData) {
                    if (_NData[i].pageId != "l1p2" && _NData[i].isVisited) {
                                visitpage++;
                    }
                }
            }
            if(typeof(gRecordData.Questions) !='undefined'){
				for(var a=0; a < gRecordData.Questions.length; a++){
					if(gRecordData.Questions[a].UserSelectedOptionId != ""){
						visitpage++;
						for(var i=0; i < gRecordData.Questions[a].Options.length; i++){
							if(gRecordData.Questions[a].Options[i].IsCorrect && gRecordData.Questions[a].Options[i].OptionId == gRecordData.Questions[a].UserSelectedOptionId){
								correctQs++;
							}
						}
					}
				}
			}
			moduleScore = Math.round((correctQs/numOfQuestion) * 100)
            return visitpage;
        },
        UpdateProgressBar: function () {
			moduleProgress = (this.GetProgressData()/numOfPagesInModule) * 100

            $(".progressForeground").css("width", moduleProgress + "%")
            $("#progressInnrDiv").text("Progress: " + Math.round(moduleProgress) + "%");

        },
        GetCurrentPage: function () {
            return _currentPageObject;
        },
        CompletePage: function (extendedJson) {
            _currentPageObject.IsComplete = true;
            _currentPageObject = $.extend(true, _currentPageObject, extendedJson)
            _StateData[_currentPageObject.pageId] = $.extend(true, {}, _currentPageObject);
        },
        GetTotalScore: function () {
            var ObtainPoint = 0;
            var totalPoints = 0;
            for (var i in _NData) {
                if (_NData[i].questions.length > 0) {
                    for (var j = 0; j < _NData[i].questions.length; j++) {
                        totalPoints = totalPoints + _QData[_NData[i].questions[j].Id].totalPoints;
                        if (_NData[i].questions[j].isAnswered != undefined && _NData[i].questions[j].isAnswered) {
                            ObtainPoint = ObtainPoint + (_NData[i].questions[j].points);
                        }
                    }
                }
            }
            var score = (ObtainPoint / totalPoints) * 100;
            return score.toFixed(0);
        },
        UpdateScore: function () {
            var percScore = this.GetTotalScore()
            $("#scoreInnrDiv").html(percScore + "%");
        },
    };
})();

function removeCSS(cssFileToRemove) {
	for(var w=0; w < document.styleSheets.length; w++ ){
		if(document.styleSheets[w].href.indexOf(cssFileToRemove) != -1 ) {
			document.styleSheets[w].disabled = true;
		}
	}
}
function addCSS(cssFileToAdd) {
	var isCSSAlreadyAdded = false;
	for(var w=0; w < document.styleSheets.length; w++ ){
		if(document.styleSheets[w].href.indexOf(cssFileToAdd) != -1 ) {
			isCSSAlreadyAdded = false;
		}
	}
	console.log(isCSSAlreadyAdded + " --")
	if(! isCSSAlreadyAdded){
		var newlink = document.createElement("link");
		newlink.setAttribute("rel", "stylesheet");
		newlink.setAttribute("type", "text/css");
		newlink.setAttribute("href", cssFileToAdd);
		document.getElementsByTagName("head").item(0).appendChild(newlink);
	}
}

function changeCSS(cssFile, cssLinkIndex) {

    var oldlink = document.getElementsByTagName("link").item(cssLinkIndex);

    var newlink = document.createElement("link");
    newlink.setAttribute("rel", "stylesheet");
    newlink.setAttribute("type", "text/css");
    newlink.setAttribute("href", cssFile);

    document.getElementsByTagName("head").item(0).replaceChild(newlink, oldlink);
}

$(document).on("click", "#linkprevious", function (event) {
    if ($(this).k_IsDisabled()) return;
    _Navigator.Prev();
});
$(document).on("click", "#linknext", function (event) {
    if ($(this).k_IsDisabled()) return;
    $(".intro-content-question").hide();
	$('.questionp').show()
    if((currentQuestionIndex +1) < gRecordData.Questions.length ){
    	addCSS('styles/questionPlaceholder.css');
	}
	else
	{
		removeCSS('styles/questionPlaceholder.css');
	}
    setTimeout('_Navigator.Next();$(".questionp").hide()',400);

});

 function setReader(idToStartReading){
	$('#hiddenAnchor').attr("href", "#" + idToStartReading)
 	$('#hiddenAnchor')[0].click()
 }