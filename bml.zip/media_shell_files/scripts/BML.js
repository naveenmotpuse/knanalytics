

/*	- total number of pages = 1+ 5+ 1+1
			- landing
			- number of questions
			- review if its seperate page // right now included in question player
			- summary if its seperate page // right now included in question player
KnowDO === Change the number as required in the module
*/
var numOfQuestion = 5
var numOfPagesInModule = 1 + numOfQuestion
var currentQuestionIndex = 0;
var introHTML  = "";
//	- Progress logic = (visitedpages / total pages ) * 100 %
//  	"visitedNumberOfPages"  -- increase this by one on every page/question -- on next click?
var visitedNumberOfPages = 0;

/*	- docuent.ready pull following data
		tracked data
			- NumOfPagesVisited, score, questions data, user id, assignment id, record id
			- Record title, Video Link
		jump to the last visited page/question

		if no tracked data found pull
 		Record title, Video Link, Question Data

KnowDO === Need service call to retrieve data
		   For proto use hardcoded data

//		QuestionsData === JSON for questions === this data is pulled from library record
	var gQuestionsData = 	{
			"QuestionSequence" : "Numbers/LowerAlphabets/UpperAlphabets/Roman/bullets/Radio",
			"OptionSequence" : "Numbers/LowerAlphabets/UpperAlphabets/Roman/bullets/Radio",
			"RandomizeQuestions" : "True/False",
			"RandomizeOptions" : "True/False",
			"Questions" : [
							{
								"QuestionId" : "1",
								"QuestionText" : "What is this?",
								"Options" : [
											 {
												"OptionId" : "1",
												"OptionText" : "this is first option",
												"IsCorrect" : "True/False",
												"CorrectFeedback" : "",
												"InCorrectFeedback" : "",
											 }
											],

								"UserSelectedOptionId" : ""

							}
						]

*/
var gRecordData = null;


 //	- Score -- number of correct attempted questions divided by total number of questions
var moduleScore = 0;

function startRecordPlayer(){
	//show record title
	window.document.title = gRecordData.RecordTitle
	$("#header-title").find("h1").text(gRecordData.RecordTitle)

	//$(".main-content").load(gRecordData.LandingPageURL)
	// init global var
	moduleScore = gRecordData.ModuleScore;
	visitedNumberOfPages = gRecordData.VisitedNumberOfPages
	if( gRecordData.Status == "NotStarted" ){
		//randomize questions
		gRecordData.Questions = shuffle(gRecordData.Questions)
	}
	else
	{
		// set currentQuestionIndex by looping through last visited question
		for(var a=0; a < gRecordData.Questions.length; a++){
			if(gRecordData.Questions[a].UserSelectedOptionId == ""){
				currentQuestionIndex = a;
			}
		}

		// if its not landing page
		if(gRecordData.LastVisitedPage != "1"  ){

		}
	}


}

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}
var isFirstQAnswered = false
var arrOptionLables = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
function showQuestion(){
 	$(".intro-content-question").hide();
 	currQustion = gRecordData.Questions[currentQuestionIndex]
	$("#QuetionText").html( "<span style='font-size:0px'>Question Number </span><span style='margin-left:-20px;'>" + (currentQuestionIndex + 1) + ") &nbsp;</span>" + currQustion.QuestionText)

	if(currQustion.UserSelectedOptionId == ""){
		// randomize options
		currQustion.Options = shuffle(currQustion.Options)
	}

	$("#linkprevious").k_enable();
	$("#linknext").k_disable();


	$(".question-band").empty();
	for(var i=0; i < currQustion.Options.length; i++){
		optionObj = $("#Option").clone();
		optionObj.attr("id", currQustion.Options[i].OptionId)
		optionObj.find(".option_txt").find("span").html("<span class='optionreader' style='font-size:0px;'>Not selected Option " + arrOptionLables[i] + " </span>" + currQustion.Options[i].OptionText)
		optionObj.find(".option_icon").find("span").text(arrOptionLables[i])
		optionObj.show()
		$(".question-band").append(optionObj)
		if(currQustion.UserSelectedOptionId == currQustion.Options[i].OptionId){
			$("#"+currQustion.Options[i].OptionId).trigger( "click" );
			$("#linknext").k_enable()
			isFirstQAnswered = true
		}
	}
	removeCSS("styles/questionplayer.css")
	$(".intro-content-question").fadeIn(600)
	$("#wrapper").css("height","auto")
	if(isFirstQAnswered){
		setReader("QuetionText")
	}
	else{
		setReader("MainHeading")
	}
}

function showSummary(){

	for(var b=0; b < gRecordData.Questions.length; b++){
		questionObj = $("#Question").clone();
		currQustion = gRecordData.Questions[b]
		questionObj.find(".quetiontext").html( "<span style='font-size:0px'>Question Number </span><span style='margin-left:-20px;'>" + (b + 1) + ") &nbsp;</span>" + currQustion.QuestionText)

		if(currQustion.UserSelectedOptionId == ""){
			// randomize options
			currQustion.Options = shuffle(currQustion.Options)
		}
		questionObj.find(".question-band").empty();
		for(var i=0; i < currQustion.Options.length; i++){
			optionObj = $("#Option").clone();
			optionObj.attr("id", currQustion.Options[i].OptionId)
			optionObj.find(".option_txt").find("span").text(currQustion.Options[i].OptionText)
			optionObj.find(".option_icon").find("span").text(arrOptionLables[i])
			optionObj.show()

			 var iscorrectimg = optionObj.find(".iscorrect").find("img")

			 if(currQustion.Options[i].IsCorrect){
					iscorrectimg.attr("src","assets/images/tick-icon-correct-1.png")
					iscorrectimg.closest("span").show();
					iscorrectimg.attr("aria-label","Correct option")
			 }
			if(currQustion.UserSelectedOptionId == currQustion.Options[i].OptionId){
				 if( ! currQustion.Options[i].IsCorrect){
					iscorrectimg.attr("src","assets/images/incorrect-v1-1.png")
					iscorrectimg.attr("aria-label","Incorrect option selected")
				 }
				 else
				 {
					 iscorrectimg.attr("aria-label","Correct option selected")
				 }

				 optionObj.addClass("optionselected")
				 iscorrectimg.closest("span").show();
			}

			questionObj.find(".question-band").append(optionObj)

		}
		questionObj.show()
		$("#Summary").append(questionObj);
	}
}