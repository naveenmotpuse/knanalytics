

$(document).on("mouseover", ".qheight", function (event) {
    $(this).css({
        "font-weight":"bold"
    });
	//console.log($(this).length + " -- " +  $(this).children(".option_icon").length  )
    $(this).find(".option_icon").find("span").css({
        "background-color":"#003058",
        "color": "#F9FF00"
    });

});
$(document).on("mouseout", ".qheight", function (event) {
    $(this).css({
        "font-weight":"normal"
    });
    $(this).find(".option_icon").find("span").css({
        "background-color":"#007AA2",
        "color": "#FFF"
    });
});
$(document).on("click", ".optionreader", function (event) {
	$(this).closest(".qheight")[0].click()
});
$(document).on("click", ".qheight", function (event) {
    $(".qheight").find(".option_icon").find("span").removeClass("optionspanselected");
    $(this).find(".option_icon").find("span").addClass("optionspanselected");

	$(".optionselected").find(".optionreader").text("Not selected option " + $(this).find(".option_icon").find("span").text() + " ")
	$(this).find(".optionreader").text("Selected option " + $(this).find(".option_icon").find("span").text() + " ")

    $(".qheight").removeClass("optionselected");
    $(this).addClass("optionselected");

	gRecordData.Questions[currentQuestionIndex].UserSelectedOptionId = $(this)
	isFirstQAnswered = true

	$("#linknext").k_enable();
	setReader($(this).attr("id"))
 });

$(document).on("click", ".infoIcon", function (event) {
    $("#infoDetails").html(introHTML);
    $("#infoDetails").slideToggle("slow", function () {

    });
});
