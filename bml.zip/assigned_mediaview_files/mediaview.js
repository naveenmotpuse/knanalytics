function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

$(document).ready(function () {
    $("#saveBtn").hide();
    $("#returnBtn").addClass("returnAssignment");
    loadAssignedViewEvents();
});

function loadAssignedViewEvents(){
    $(".modPreviewBtn").on("click",function(){
        var recordId = Number($(this).attr("recordId"))
        $("#framePreview").attr("src", "/content/media_shell_files/index.htm?id="+recordId);
        $("#shellFrame").show()
        $("#saveBtn").show();
        $("#saveBtn").attr("record_id",recordId)
        $("#returnBtn").addClass("returnShell");
        $("#returnBtn").removeClass("returnAssignment");
        $(".innerWrapper").hide();
    });

    $("#returnBtn").on("click",function(){
        if($(this).hasClass("returnShell")){
            $("#returnBtn").removeClass("returnShell");
            $("#returnBtn").addClass("returnAssignment");
            $("#shellFrame").load("");
            $("#shellFrame").hide()
            $("#saveBtn").hide();
            $(".innerWrapper").show();
        }
    })

    $("#saveBtn").on("click",function(){
    debugger;
        recordId = Number($("#saveBtn").attr("record_id"))
        $(".media-library").attr("record_id",recordId)
        assignmentId =  $(".media-library").attr("assignment_id")
        url_value = "/media_library/getSaveAssignmentView"
        data = {'csrfmiddlewaretoken':$("input[name='csrfmiddlewaretoken']").val(), 'recordId':  recordId, "assignmentId":assignmentId}

        $.ajax({
           type: "POST",
           url: url_value,
           async: false,
           data: data,
           success: function callback(data){
                $("#returnBtn").removeClass("returnShell");
                $("#returnBtn").addClass("returnAssignment");
                $("#shellFrame").load("");
                $("#shellFrame").hide()
                $("#saveBtn").hide();
                $(".innerWrapper").show();
                $(".media-row").remove();
                $(".media-group").append(data)
            },
            error: function (xhr, data, message) {
            debugger;
                $("#returnBtn").removeClass("returnShell");
                $("#returnBtn").addClass("returnAssignment");
                $("#shellFrame").load("");
                $("#shellFrame").hide()
                $("#saveBtn").hide();
                $("#returnBtn").hide();
                $(".innerWrapper").show();
                console.log("Error while pulling data for record id ")
            }
        });
    })

$("#asgn_media_search").on('keyup', function (event) {
    if (window.event) {
        key = window.event.keyCode;
    } else if (event) {
        key = event.keyCode;
    }
    // Was the Enter key pressed?
    if (key == 13) {
        searchContent = $(this).val();
        recordId = Number($(".media-library").attr("record_id"))

        url_value = "/media_library/getSearchMediaView"
        data =  {'csrfmiddlewaretoken':$("input[name='csrfmiddlewaretoken']").val(), 'searchContent':  searchContent}
        if(searchContent == ""){
            url_value = "/media_library/getAssignedMediaView"
            data =  {'csrfmiddlewaretoken':$("input[name='csrfmiddlewaretoken']").val(), 'recordId':  recordId, "showPartialView":"show"}
        }
        $.ajax({
           type: "POST",
           url: url_value,
           async: false,
           data: data,
           success: function callback(data){
                console.log(data)
                $(".media-row").remove();
                $(".media-group").append(data)
            },
            error: function (xhr, data, message) {
            debugger;
                console.log("Error while pulling data for record id ")
            }
        });
    }
})
}
