from django.http import HttpResponse
from django.shortcuts import render
from .models import MediaLibrary
from .models import MediaAsignments
from django.http import JsonResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import json


def index(request):
    media_library_list = MediaLibrary.objects.all
    context = {"media_library_list": media_library_list}
    return HttpResponse(render(request, 'medialibrary/index.html', context))


def getAssignedMediaView(request):
    view_row_length = 3
    assigned_record_id = 1
    show_partial_view = ""
    related_media_list = []
    assignment_id = "assignment_1"

    if request.method == "POST" and request.is_ajax():
        show_partial_view = request.POST.get('showPartialView')
        assigned_record_id = request.POST.get('recordId', None)
    else:
        assigned_record_id = request.GET.get('recordId', None)
        assignment_id = request.GET.get('assignmentId',None)

    assigned_media_record = list(MediaLibrary.objects.filter(record_id=assigned_record_id))
    if len(assigned_media_record)>0:
        assigned_metadata_list = assigned_media_record[0].metadata.split(";")
        media_library_list = MediaLibrary.objects.all()
        placeholder_listset = [assigned_media_record[0]]
        placeholder_list = [assigned_media_record[0]]
        for metadata in assigned_metadata_list:
            for media in media_library_list:
                existInRecord = False
                media_metadata_list = media.metadata.split(";")
                for mediameta in media_metadata_list:
                    if set(metadata).issubset(mediameta):
                        existInRecord = True
                if existInRecord and not media in placeholder_list:
                    placeholder_list.append(media)
                    placeholder_listset.append(media)
                    if len(placeholder_listset) == view_row_length:
                        related_item = tuple(placeholder_listset)
                        related_media_list.append(related_item)
                        placeholder_listset = []
        if len(placeholder_listset) > 0:
            related_item = tuple(placeholder_listset)
            related_media_list.append(related_item)

    if show_partial_view == "show" or show_partial_view is None:
        context = {"related_media_list": related_media_list}
        return HttpResponse(render(request, 'medialibrary/searchMediaView.html', context))
    else:
        context = {"related_media_list": related_media_list, "assignment_id": assignment_id}
        return HttpResponse(render(request, 'medialibrary/assignedMediaView.html', context))


def getSearchMediaView(request):
    search_content = ""
    searchresults = ""
    if request.method == "POST" and request.is_ajax():
        search_content = request.POST.get('searchContent')
    view_row_length = 3
    media_library_list = MediaLibrary.objects.all()
    related_media_list = []
    placeholder_listset = []
    placeholder_list = []
    for media in media_library_list:
        existInRecord = False
        media_metadata = media.metadata
        media_title = media.record_title
        if search_content.lower() in media_metadata.lower() or search_content.lower() in media_title.lower():
            if media_metadata != "" and media_title != "":
                existInRecord = True
        if existInRecord and not media in placeholder_list:
            searchresults = searchresults + "### " + media_title + "---" + media.metadata
            placeholder_list.append(media)
            placeholder_listset.append(media)
            if len(placeholder_listset) == view_row_length:
                related_item = tuple(placeholder_listset)
                related_media_list.append(related_item)
                placeholder_listset = []
    if len(placeholder_listset) > 0:
        related_item = tuple(placeholder_listset)
        related_media_list.append(related_item)
    context = {"related_media_list": related_media_list}
    return HttpResponse(render(request, 'medialibrary/searchMediaView.html', context))


def getSaveAssignmentView(request):
    view_row_length = 3
    assigned_record_id = 1

    related_media_list = []

    if request.method == "POST" and request.is_ajax():
        assigned_record_id = request.POST.get('recordId', None)
        assignment_id = request.POST.get('assignmentId', None)

    existingAssignment = list(MediaAsignments.objects.filter(assignment_id=assignment_id))
    if len(existingAssignment) > 0:
        MediaAsignments.objects.filter(assignment_id=assignment_id).update(media_record_id=assigned_record_id)
    else:
        media_assignments = MediaAsignments(assignment_id=assignment_id, media_record_id=assigned_record_id)
        media_assignments.save()

    return HttpResponse(getAssignedMediaView(request))


def getRequestedMediaJson(request):
    recordId = 1
    if request.method == "POST" and request.is_ajax():
        recordId = request.POST.get('record_Id')

    media_library_record = MediaLibrary.objects.filter(record_id=recordId)
    recordMCQ = ""
    videoInfo = ""
    for media in media_library_record:
        recordMCQ = media.media_mcq
        videoInfo = media.video_info

    if recordMCQ != "":
        recordMCQ = json.loads(recordMCQ)
        recordMCQ["LandingPageContent"] = videoInfo
        recordMCQ = json.dumps(recordMCQ)
        return HttpResponse(recordMCQ)
    else:
        return HttpResponse("No Records")

def setRequestedMediaJson(request):
    recordId = 1
    if request.method == "POST" and request.is_ajax():
        recordId = request.POST.get('record_Id')
        jsonData = request.GET.get('data', None)
    MediaLibrary.objects.filter(record_id=recordId).update(media_mcq=jsonData)
    return HttpResponse("Success")
