from django.apps import AppConfig


class MediaLibraryConfig(AppConfig):
    name = 'media_library'
