from django.urls import path
from django.urls import re_path
from django.conf.urls import url

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    url(r'^getRequestedMediaJson', views.getRequestedMediaJson, name='getRequestedMediaJson'),
    url(r'^setRequestedMediaJson', views.setRequestedMediaJson, name='setRequestedMediaJson'),
    url(r'^getSaveAssignmentView', views.getSaveAssignmentView, name='getSaveAssignmentView'),
    re_path(r'^getAssignedMediaView', views.getAssignedMediaView, name='getAssignedMediaView'),
    re_path(r'^getSearchMediaView', views.getSearchMediaView, name='getSearchMediaView'),
]
