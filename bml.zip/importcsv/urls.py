from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    #path('createnewtable', views.createnewtable, name='createnewtable'),
    path('importcsvtotable', views.importcsvtotable, name='importcsvtotable'),
]
