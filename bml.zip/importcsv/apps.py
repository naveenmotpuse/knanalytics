from django.apps import AppConfig


class ImportcsvConfig(AppConfig):
    name = 'importcsv'
