var _pageCounter = {"currentPage": 1, "totalPages": 0}


$(document).ready(function () {
    $("#returnBtn").addClass("returnAssignment");
    loadAssignedViewEvents();
    reloadPages()
});

function loadAssignedViewEvents(){
    $(".modPreviewBtn").on("click",function(){
        var recordId = Number($(this).attr("recordId"))
        $("#framePreview").attr("src", "/content/media_shell_files/index.htm?id="+recordId);
        $("#shellFrame").show()
        if(!$(this).hasClass("assignedMedia")){
            $("#saveBtn").show();
            $("#saveBtn").attr("record_id",recordId)
        }
        $("#returnBtn").addClass("returnShell");
        $("#returnBtn").removeClass("returnAssignment");
        $(".innerWrapper").hide();
    });

    $(".modSaveBtn").on("click",function(){
    debugger;
        recordId = Number($(this).attr("recordid"))
        assignmentId =  $(".media-library").attr("assignment_id")
        customTarget =  $(".media-library").attr("custom_target")
        url_value = "/media_library/getSaveAssignmentView"
        data = {'csrfmiddlewaretoken': $("input[name='csrfmiddlewaretoken']").val(), 'recordId':  recordId, "assignmentId":assignmentId, "customTarget":customTarget}

        $.ajax({
           type: "POST",
           url: url_value,
           async: false,
           data: data,
           success: function callback(data){
                debugger;
                $(".media-library").html("")
                data = data.replace("<!DOCTYPE html>","")
                $(".media-library").html(data);
                loadAssignedViewEvents()
                reloadPages()
            },
            error: function (xhr, data, message) {
            debugger;
                $("#returnBtn").removeClass("returnShell");
                $("#returnBtn").addClass("returnAssignment");
                $("#shellFrame").load("");
                $("#shellFrame").hide()
                $("#saveBtn").hide();
                $("#returnBtn").hide();
                $(".innerWrapper").show();
                console.log("Error while pulling data for record id ")
            }
        });
    })

    $(".modEditBtn").on("click",function(){
        var recordId = Number($(this).attr("recordId"))
        $("#shellFrame").attr("src", "/static/media_library/addEdit_Asgnview_files/add_edit_assignment_view.html?id="+recordId);
        $("#shellFrame").show();
        $(".shellFrame").show();
        $("#returnBtn").addClass("returnShell");
        $("#returnBtn").removeClass("returnAssignment");
        $(".innerWrapper").hide();
    });

    $("#returnBtn").on("click",function(){
        if($(this).hasClass("returnShell")){
            $("#returnBtn").removeClass("returnShell");
            $("#returnBtn").addClass("returnAssignment");
            $("#shellFrame").load("");
            $("#shellFrame").hide()
            $("#saveBtn").hide();
            $(".innerWrapper").show();
        }
    })

    $("#asgn_media_search").on('keyup', function (event) {
        if (window.event) {
            key = window.event.keyCode;
        } else if (event) {
            key = event.keyCode;
        }
        // Was the Enter key pressed?
        if (key == 13) {
            searchContent = $(this).val();

            url_value = "/media_library/getSearchMediaView"
            data =  {'csrfmiddlewaretoken': $("input[name='csrfmiddlewaretoken']").val(), 'searchContent':  searchContent, "showPartialView":"show"}
            if(searchContent == ""){
                data =  {'csrfmiddlewaretoken': $("input[name='csrfmiddlewaretoken']").val()}
            }
            $.ajax({
               type: "POST",
               url: url_value,
               async: false,
               data: data,
               success: function callback(data){
                    $(".media-group-all").remove();
                    $(".search-filter").after(data);
                    $(".current_page").attr("totalmedia", $(".media-group-all").find(".media-video").length)
                    reloadPages();
                },
                error: function (xhr, data, message) {
                debugger;
                    console.log("Error while pulling data for record id ")
                }
            });
        }
    })

    $("#filter-dropdown").on("change",function(){
        filterContent = $(this).find('option:selected').val()

        recordId = Number($(".media-library").attr("record_id"))

        url_value = "/media_library/getFilterMediaView"
        data =  {'csrfmiddlewaretoken': $("input[name='csrfmiddlewaretoken']").val(), 'filterContent':  filterContent, "showPartialView":"show"}
        if(filterContent == ""){
            data = {'csrfmiddlewaretoken': $("input[name='csrfmiddlewaretoken']").val()}
        }
        $.ajax({
           type: "POST",
           url: url_value,
           async: false,
           data: data,
           success: function callback(data){
                $(".media-group-all").remove();
                $(".search-filter").after(data);
                $(".current_page").attr("totalmedia", $(".media-group-all").find(".media-video").length)
                reloadPages();
            },
            error: function (xhr, data, message) {
            debugger;
                console.log("Error while pulling data for record id ")
            }
        });
    })

    $("#link_more").on("click",function(){
        _pageCounter.currentPage++;
        reloadPages()
    })
}

function reloadPages(){
    debugger;
    var displaying = 0;
    if($(".page").length>0){
        $(".page").each(function(){
            if(Number($(this).attr("pagenumber")) <= _pageCounter.currentPage){
                $(this).show();
                displaying += $(this).find(".media-video").length;
            }else{
                $(this).hide();
            }
        })
    }

    $(".current_page").text("Displaying " +  displaying + " of " + $(".current_page").attr("totalmedia"));
    if(displaying == Number($(".current_page").attr("totalmedia"))){
        $("#link_more").hide();
    }else{
        $("#link_more").show();
    }
}